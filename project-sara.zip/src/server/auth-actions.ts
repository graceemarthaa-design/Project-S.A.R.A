"use server"

import { compare } from "bcryptjs"
import { AuthError } from "next-auth"
import { auth, signIn, signOut } from "@/auth"
import { prisma } from "@/lib/db"
import { homePath } from "@/lib/permissions"

export type LoginState = { error?: string } | undefined

export async function login(
  _previous: LoginState,
  formData: FormData,
): Promise<LoginState> {
  const email = String(formData.get("email") ?? "")
    .trim()
    .toLowerCase()
  const password = String(formData.get("password") ?? "")

  if (!email || !password) {
    return { error: "Enter the email and password for your classroom account." }
  }

  const user = await prisma.user.findUnique({ where: { email } })
  if (!user) {
    return { error: "That email and password were not recognized." }
  }

  const matches = await compare(password, user.passwordHash)
  if (!matches) {
    return { error: "That email and password were not recognized." }
  }

  if (user.status !== "active") {
    return { error: "This account is turned off. Ask an admin to enable it." }
  }

  try {
    await signIn("credentials", {
      email,
      password,
      redirectTo: homePath(user.role),
    })
  } catch (error) {
    if (error instanceof AuthError) {
      return { error: "That email and password were not recognized." }
    }
    throw error
  }
}

export async function logout() {
  const session = await auth()
  if (session?.user?.id) {
    await prisma.auditEvent.create({
      data: {
        actorId: session.user.id,
        action: "auth.sign_out",
        entityType: "User",
        entityId: session.user.id,
        metadata: { role: session.user.role },
      },
    })
  }
  await signOut({ redirectTo: "/login" })
}
