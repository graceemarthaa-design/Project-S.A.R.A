import Link from "next/link"
import type { Area } from "@/lib/areas"
import { AreaIcon } from "@/components/area-icon"
import { PageHeader } from "@/components/page-header"
import { StatusStrip } from "@/components/status-strip"
import type { StatusView } from "@/lib/sara/status"

export function HomeDashboard({
  eyebrow,
  title,
  description,
  note,
  areas,
  status,
}: {
  eyebrow: string
  title: string
  description: string
  note: string
  areas: Area[]
  status: StatusView | null
}) {
  return (
    <div className="space-y-8">
      <PageHeader eyebrow={eyebrow} title={title} description={description} />
      <StatusStrip status={status} />
      <p className="max-w-2xl text-sm leading-relaxed text-muted-foreground">{note}</p>
      <ul className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {areas.map((area) => (
          <li key={area.href}>
            <Link
              href={area.href}
              className="flex h-full flex-col rounded-2xl bg-card p-5 ring-1 ring-foreground/10 transition-colors hover:ring-primary/40"
            >
              <AreaIcon name={area.icon} className="size-4 text-primary" />
              <span className="mt-4 font-medium">{area.label}</span>
              <span className="mt-1 text-sm leading-relaxed text-muted-foreground">
                {area.description}
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  )
}
