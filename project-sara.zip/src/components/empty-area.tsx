import type { Area } from "@/lib/areas"
import { AreaIcon } from "@/components/area-icon"
import { PageHeader } from "@/components/page-header"

export function EmptyArea({ area }: { area: Area }) {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow={area.eyebrow}
        title={area.title}
        description={area.description}
      />
      <section className="max-w-xl rounded-2xl border border-dashed border-border bg-card/70 px-6 py-10">
        <AreaIcon name={area.icon} className="size-5 text-primary" />
        <h2 className="mt-4 font-display text-2xl tracking-tight">
          {area.emptyTitle}
        </h2>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          {area.emptyBody}
        </p>
      </section>
    </div>
  )
}
