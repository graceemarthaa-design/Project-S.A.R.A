import { PageHeader } from "@/components/page-header"

export function AccessDenied({
  eyebrow,
  title,
  body,
}: {
  eyebrow: string
  title: string
  body: string
}) {
  return (
    <div className="space-y-8">
      <PageHeader eyebrow={eyebrow} title={title} />
      <section className="max-w-xl rounded-2xl border border-border bg-card px-6 py-8">
        <h2 className="font-display text-2xl tracking-tight">
          This stays closed.
        </h2>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          {body}
        </p>
      </section>
    </div>
  )
}
