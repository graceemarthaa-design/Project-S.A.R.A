"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, X } from "lucide-react"
import { logout } from "@/server/auth-actions"
import type { NavItem } from "@/lib/areas"
import type { StatusView } from "@/lib/sara/status"
import { AreaIcon } from "@/components/area-icon"
import { Brand } from "@/components/brand"
import { Button } from "@/components/ui/button"
import { cn } from "cn"

export function ConsoleShell({
  user,
  items,
  status,
  children,
}: {
  user: { name: string; roleLabel: string }
  items: NavItem[]
  status: StatusView | null
  children: React.ReactNode
}) {
  const pathname = usePathname()
  const [menuPath, setMenuPath] = useState<string | null>(null)
  const open = menuPath === pathname

  return (
    <div className="min-h-full lg:grid lg:grid-cols-[16.5rem_minmax(0,1fr)]">
      <aside className="sticky top-0 hidden h-screen flex-col bg-sidebar text-sidebar-foreground lg:flex">
        <div className="px-5 pt-6">
          <Brand tone="pine" />
        </div>
        <nav className="mt-8 flex-1 space-y-1 overflow-y-auto px-3" aria-label="Classroom">
          {items.map((item) => (
            <NavLink key={item.href} item={item} pathname={pathname} />
          ))}
        </nav>
        <div className="border-t border-sidebar-border px-4 py-4">
          <UserBlock user={user} tone="pine" />
        </div>
      </aside>

      <div className="flex min-w-0 flex-col">
        <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-background/90 px-4 py-3 backdrop-blur lg:hidden">
          <Brand compact />
          <Button
            type="button"
            variant="outline"
            size="icon"
            aria-expanded={open}
            aria-controls="mobile-nav"
            onClick={() => setMenuPath(open ? null : pathname)}
          >
            {open ? <X /> : <Menu />}
            <span className="sr-only">{open ? "Close menu" : "Open menu"}</span>
          </Button>
        </header>

        {open ? (
          <div className="fixed inset-0 z-30 lg:hidden" id="mobile-nav">
            <button
              type="button"
              className="absolute inset-0 bg-foreground/40"
              aria-label="Close menu"
              onClick={() => setMenuPath(null)}
            />
            <div className="absolute inset-y-0 right-0 flex w-[min(100%,20rem)] flex-col bg-sidebar text-sidebar-foreground shadow-xl">
              <div className="flex items-center justify-between px-5 pt-6">
                <Brand tone="pine" />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="text-sidebar-foreground hover:bg-sidebar-accent"
                  onClick={() => setMenuPath(null)}
                >
                  <X />
                  <span className="sr-only">Close menu</span>
                </Button>
              </div>
              <nav className="mt-8 flex-1 space-y-1 overflow-y-auto px-3" aria-label="Classroom">
                {items.map((item) => (
                  <NavLink key={item.href} item={item} pathname={pathname} />
                ))}
              </nav>
              <div className="border-t border-sidebar-border px-4 py-4">
                <UserBlock user={user} tone="pine" />
              </div>
            </div>
          </div>
        ) : null}

        <div className="border-b border-border px-5 py-3 lg:px-10">
          <p className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-2 text-foreground">
              <span className="size-2 rounded-full bg-brass" aria-hidden />
              S.A.R.A. {status ? status.connectivity : "unreported"}
            </span>
            <span aria-hidden>·</span>
            <span>
              {status?.cameraState === "not_connected" || !status
                ? "Camera not connected"
                : `Camera ${status.cameraState}`}
            </span>
          </p>
        </div>

        <main className="flex-1 px-5 py-8 lg:px-10 lg:py-10">{children}</main>
      </div>
    </div>
  )
}

function NavLink({ item, pathname }: { item: NavItem; pathname: string }) {
  const active =
    item.href === "/student" || item.href === "/staff"
      ? pathname === item.href
      : pathname === item.href || pathname.startsWith(`${item.href}/`)

  return (
    <Link
      href={item.href}
      className={cn(
        "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
        active
          ? "bg-sidebar-accent text-sidebar-accent-foreground"
          : "text-sidebar-foreground/80 hover:bg-sidebar-accent/70 hover:text-sidebar-accent-foreground",
      )}
      aria-current={active ? "page" : undefined}
    >
      <AreaIcon name={item.icon} className="size-4" />
      {item.label}
    </Link>
  )
}

function UserBlock({
  user,
  tone,
}: {
  user: { name: string; roleLabel: string }
  tone: "pine"
}) {
  return (
    <div className="space-y-3">
      <div>
        <p className="text-sm font-medium">{user.name}</p>
        <p
          className={cn(
            "text-xs tracking-wide uppercase",
            tone === "pine" && "text-sidebar-foreground/65",
          )}
        >
          {user.roleLabel}
        </p>
      </div>
      <form action={logout}>
        <Button
          type="submit"
          variant="outline"
          className="w-full border-sidebar-border bg-transparent text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
        >
          Sign out
        </Button>
      </form>
    </div>
  )
}
