"use client"

import { useActionState, useState } from "react"
import { login, type LoginState } from "@/server/auth-actions"
import { demoAccounts } from "@/lib/demo-accounts"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const initialState: LoginState = undefined

export function LoginForm() {
  const [state, action, pending] = useActionState(login, initialState)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  return (
    <form action={action} className="space-y-5">
      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          name="email"
          type="email"
          autoComplete="username"
          required
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          className="h-11 bg-card px-3 text-base"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <Input
          id="password"
          name="password"
          type="password"
          autoComplete="current-password"
          required
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          className="h-11 bg-card px-3 text-base"
        />
      </div>
      {state?.error ? (
        <p role="alert" className="text-sm text-destructive">
          {state.error}
        </p>
      ) : null}
      <Button type="submit" size="lg" className="h-11 w-full" disabled={pending}>
        {pending ? "Signing in…" : "Sign in"}
      </Button>

      <div className="rounded-xl border border-border bg-muted/60 p-4">
        <p className="text-sm font-medium">Classroom demo accounts</p>
        <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
          These three accounts are seeded locally. Choosing one fills the form.
        </p>
        <ul className="mt-3 space-y-2">
          {demoAccounts.map((account) => (
            <li key={account.email}>
              <button
                type="button"
                className="flex w-full items-center justify-between gap-3 rounded-lg border border-border bg-card px-3 py-2 text-left text-sm hover:border-primary/40"
                onClick={() => {
                  setEmail(account.email)
                  setPassword(account.password)
                }}
              >
                <span>
                  <span className="block font-medium">{account.name}</span>
                  <span className="text-xs text-muted-foreground">{account.email}</span>
                </span>
                <span className="text-[11px] tracking-wide text-brass uppercase">
                  {account.label}
                </span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </form>
  )
}
