import {
  Calculator,
  CalendarDays,
  ClipboardList,
  GraduationCap,
  House,
  LifeBuoy,
  Megaphone,
  MessageCircle,
  Radio,
  School,
  Shield,
  Users,
  type LucideIcon,
} from "lucide-react"
import type { AreaIconName } from "@/lib/areas"

const icons: Record<AreaIconName, LucideIcon> = {
  home: House,
  calendar: CalendarDays,
  megaphone: Megaphone,
  tasks: ClipboardList,
  grades: GraduationCap,
  calculator: Calculator,
  help: LifeBuoy,
  message: MessageCircle,
  classes: School,
  gradebook: GraduationCap,
  orders: Radio,
  status: Radio,
  shield: Shield,
  people: Users,
}

export function AreaIcon({
  name,
  className,
}: {
  name: AreaIconName
  className?: string
}) {
  const Icon = icons[name]
  return <Icon className={className} aria-hidden />
}
