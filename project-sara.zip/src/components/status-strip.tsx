import { cameraLabel, connectivityLabel, type StatusView } from "@/lib/sara/status"

export function StatusStrip({ status }: { status: StatusView | null }) {
  const label = status
    ? connectivityLabel(status.connectivity)
    : "No report"
  const camera = status ? cameraLabel(status.cameraState) : "Camera not connected"

  return (
    <p className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
      <span className="inline-flex items-center gap-2 text-foreground">
        <span className="size-2 rounded-full bg-brass" aria-hidden />
        S.A.R.A. {label.toLowerCase()}
      </span>
      <span aria-hidden>·</span>
      <span>{camera}</span>
    </p>
  )
}
