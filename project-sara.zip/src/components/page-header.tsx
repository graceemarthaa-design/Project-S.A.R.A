export function PageHeader({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string
  title: string
  description?: string
}) {
  return (
    <header className="max-w-2xl">
      <p className="text-[11px] font-medium tracking-[0.18em] text-brass uppercase">
        {eyebrow}
      </p>
      <h1 className="mt-2 font-display text-4xl tracking-tight text-balance">
        {title}
      </h1>
      {description ? (
        <p className="mt-3 text-base leading-relaxed text-muted-foreground">
          {description}
        </p>
      ) : null}
    </header>
  )
}
