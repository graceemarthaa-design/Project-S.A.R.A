import { cn } from "cn"

export function Brand({
  tone = "paper",
  compact = false,
}: {
  tone?: "paper" | "pine"
  compact?: boolean
}) {
  return (
    <div className={cn("flex items-center gap-3", compact && "gap-2")}>
      <span
        className={cn(
          "relative grid size-9 place-items-center rounded-full border font-display text-sm",
          tone === "pine"
            ? "border-sidebar-border bg-sidebar-accent text-sidebar-foreground"
            : "border-border bg-primary text-primary-foreground",
        )}
        aria-hidden
      >
        S
        <span className="absolute -right-0.5 -top-0.5 size-2.5 rounded-full bg-brass ring-2 ring-background" />
      </span>
      <div className="leading-tight">
        <p className="font-display text-lg tracking-wide">S.A.R.A.</p>
        {!compact ? (
          <p
            className={cn(
              "text-[11px] tracking-[0.16em] uppercase",
              tone === "pine"
                ? "text-sidebar-foreground/70"
                : "text-muted-foreground",
            )}
          >
            Classroom
          </p>
        ) : null}
      </div>
    </div>
  )
}
