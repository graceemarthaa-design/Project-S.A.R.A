import type { Metadata } from "next"
import { EmptyArea } from "@/components/empty-area"
import { PageHeader } from "@/components/page-header"
import { staffAreas } from "@/lib/areas"
import { formatWhen } from "@/lib/format"
import { cameraLabel, connectivityLabel, getLatestStatus } from "@/lib/sara/status"

export const metadata: Metadata = { title: "Status and camera" }

export default async function StatusPage() {
  const status = await getLatestStatus()
  if (!status) return <EmptyArea area={staffAreas.status} />

  const rows = [
    ["Connectivity", connectivityLabel(status.connectivity)],
    ["Mode", status.mode],
    ["Battery", status.battery === null ? "No reading" : `${status.battery}%`],
    ["Camera", cameraLabel(status.cameraState)],
    ["Recorded", `${formatWhen(status.recordedAt)} UTC`],
  ]

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow={staffAreas.status.eyebrow}
        title={staffAreas.status.title}
        description={staffAreas.status.description}
      />
      <section className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <dl className="rounded-2xl bg-card p-6 ring-1 ring-foreground/10">
          {rows.map(([label, value]) => (
            <div key={label} className="grid grid-cols-[8rem_1fr] gap-3 border-b border-border py-3 last:border-0">
              <dt className="text-sm text-muted-foreground">{label}</dt>
              <dd className="text-sm font-medium">{value}</dd>
            </div>
          ))}
          <p className="pt-4 text-sm leading-relaxed text-muted-foreground">{status.note}</p>
        </dl>
        <div className="flex min-h-64 flex-col justify-between rounded-2xl border border-dashed border-border bg-primary px-6 py-6 text-primary-foreground">
          <p className="text-[11px] tracking-[0.18em] text-brass uppercase">Camera</p>
          <div>
            <h2 className="font-display text-3xl tracking-tight">Camera not connected</h2>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-primary-foreground/80">
              The classroom view will appear here when the physical S.A.R.A. offers a stream. Students never receive that view.
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}
