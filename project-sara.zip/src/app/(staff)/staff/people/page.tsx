import type { Metadata } from "next"
import { redirect } from "next/navigation"
import { auth } from "@/auth"
import { AccessDenied } from "@/components/access-denied"
import { PageHeader } from "@/components/page-header"
import { prisma } from "@/lib/db"
import { staffAreas } from "@/lib/areas"
import { canViewPeople, publicAccountSelect, roleLabel } from "@/lib/permissions"

export const metadata: Metadata = { title: "People" }

export default async function PeoplePage() {
  const session = await auth()
  if (!session?.user) redirect("/login")

  if (!canViewPeople(session.user.role)) {
    return (
      <AccessDenied
        eyebrow="Accounts"
        title="People"
        body="The account directory is an admin screen. Teachers work inside their own classes and do not browse every account from here."
      />
    )
  }

  const people = await prisma.user.findMany({
    select: publicAccountSelect,
    orderBy: [{ role: "asc" }, { displayName: "asc" }],
  })

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow={staffAreas.people.eyebrow}
        title={staffAreas.people.title}
        description={staffAreas.people.description}
      />
      <p className="max-w-2xl text-sm leading-relaxed text-muted-foreground">
        Personal profile fields are stored apart from these accounts and are not listed here.
      </p>
      {people.length === 0 ? (
        <p className="text-sm text-muted-foreground">{staffAreas.people.emptyTitle}</p>
      ) : (
        <ul className="overflow-hidden rounded-2xl bg-card ring-1 ring-foreground/10">
          {people.map((person) => (
            <li
              key={person.id}
              className="grid gap-1 border-b border-border px-4 py-4 last:border-0 sm:grid-cols-[minmax(0,1.2fr)_minmax(0,1.4fr)_7rem_6rem] sm:items-center"
            >
              <span className="font-medium">{person.displayName}</span>
              <span className="text-sm text-muted-foreground">{person.email}</span>
              <span className="text-sm">{roleLabel(person.role)}</span>
              <span className="text-sm capitalize text-muted-foreground">{person.status}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
