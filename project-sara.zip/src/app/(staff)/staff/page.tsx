import type { Metadata } from "next"
import { auth } from "@/auth"
import { HomeDashboard } from "@/components/home-dashboard"
import { staffNav } from "@/lib/areas"
import { firstName } from "@/lib/format"

import { getLatestStatus } from "@/lib/sara/status"

export const metadata: Metadata = { title: "Classroom console" }

export default async function StaffHomePage() {
  const session = await auth()
  const role = session?.user?.role === "admin" ? "admin" : "teacher"
  const name = firstName(session?.user?.name ?? "there")
  const status = await getLatestStatus()
  const areas = staffNav.filter(
    (area) => area.href !== "/staff" && (!area.adminOnly || role === "admin"),
  )

  const description =
    role === "admin"
      ? "You manage accounts and the school classroom tools. Personal student details stay behind an explicit grant."
      : "You see the classes assigned to you. Personal student details stay hidden unless an admin grants access."

  return (
    <HomeDashboard
      eyebrow={role === "admin" ? "Admin" : "Teacher"}
      title={`${name}, this is the classroom console.`}
      description={description}
      note="Orders you leave for S.A.R.A. will wait in a queue. The robot is not connected, and the camera stays dark."
      areas={areas}
      status={status}
    />
  )
}
