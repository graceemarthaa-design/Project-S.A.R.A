import type { Metadata } from "next"
import { EmptyArea } from "@/components/empty-area"
import { staffAreas } from "@/lib/areas"

const area = staffAreas.gradebook
export const metadata: Metadata = { title: area.label }

export default function GradebookPage() {
  return <EmptyArea area={area} />
}
