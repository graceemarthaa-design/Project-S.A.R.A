import type { Metadata } from "next"
import { redirect } from "next/navigation"
import { auth } from "@/auth"
import { AccessDenied } from "@/components/access-denied"
import { EmptyArea } from "@/components/empty-area"
import { staffAreas } from "@/lib/areas"
import { canManageGrants } from "@/lib/permissions"

export const metadata: Metadata = { title: "Personal-data grants" }

export default async function GrantsPage() {
  const session = await auth()
  if (!session?.user) redirect("/login")

  if (!canManageGrants(session.user.role)) {
    return (
      <AccessDenied
        eyebrow="Privacy"
        title="Personal-data grants"
        body="Student numbers, phone numbers, addresses, and guardian details open only when an admin records a grant. A teacher account does not include that access."
      />
    )
  }

  return <EmptyArea area={staffAreas.grants} />
}
