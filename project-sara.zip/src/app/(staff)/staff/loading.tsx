export default function StaffLoading() {
  return <p className="text-sm text-muted-foreground">Opening the classroom console…</p>
}
