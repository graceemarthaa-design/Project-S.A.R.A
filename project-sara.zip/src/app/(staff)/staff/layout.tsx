import { redirect } from "next/navigation"
import { auth } from "@/auth"
import { ConsoleShell } from "@/components/console-shell"
import { navForRole } from "@/lib/areas"
import { isStaff, roleLabel } from "@/lib/permissions"
import { getLatestStatus } from "@/lib/sara/status"

export const dynamic = "force-dynamic"

export default async function StaffLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const session = await auth()
  if (!session?.user) redirect("/login")
  if (!isStaff(session.user.role)) redirect("/student")

  const status = await getLatestStatus()

  return (
    <ConsoleShell
      user={{
        name: session.user.name ?? "Staff",
        roleLabel: roleLabel(session.user.role),
      }}
      items={navForRole(session.user.role)}
      status={status}
    >
      {children}
    </ConsoleShell>
  )
}
