import Link from "next/link"
import { Brand } from "@/components/brand"

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-full max-w-lg flex-col justify-center px-6 py-16">
      <Brand />
      <h1 className="mt-10 font-display text-4xl tracking-tight">
        That page is not in the classroom.
      </h1>
      <p className="mt-3 text-muted-foreground">
        The address does not match a student or staff screen.
      </p>
      <Link href="/" className="mt-8 text-sm font-medium text-primary underline-offset-4 hover:underline">
        Return to sign in
      </Link>
    </div>
  )
}
