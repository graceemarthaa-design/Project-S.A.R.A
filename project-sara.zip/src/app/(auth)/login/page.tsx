import type { Metadata } from "next"
import { redirect } from "next/navigation"
import { auth } from "@/auth"
import { Brand } from "@/components/brand"
import { LoginForm } from "@/components/login-form"
import { homePath } from "@/lib/permissions"

export const dynamic = "force-dynamic"

export const metadata: Metadata = {
  title: "Sign in",
}

export default async function LoginPage() {
  const session = await auth()
  if (session?.user) redirect(homePath(session.user.role))

  return (
    <div className="grid min-h-full lg:grid-cols-[minmax(0,1.05fr)_minmax(22rem,0.95fr)]">
      <section className="relative hidden flex-col justify-between overflow-hidden bg-primary px-12 py-12 text-primary-foreground lg:flex">
        <Brand tone="pine" />
        <div className="max-w-md">
          <p className="text-[11px] tracking-[0.2em] text-brass uppercase">
            Project S.A.R.A.
          </p>
          <h1 className="mt-4 font-display text-5xl leading-[1.05] tracking-tight text-balance">
            Two doors into the same classroom.
          </h1>
          <ul className="mt-8 space-y-4 text-sm leading-relaxed text-primary-foreground/85">
            <li>Staff publish class work, keep the gradebook, and leave orders for S.A.R.A.</li>
            <li>Students follow their schedule and a history of their own grade changes.</li>
            <li>Personal details stay closed unless an admin grants access.</li>
          </ul>
        </div>
        <p className="text-sm text-primary-foreground/75">
          Physical S.A.R.A. is not connected. Orders will wait in a queue.
        </p>
      </section>

      <section className="flex flex-col justify-center px-6 py-12 sm:px-12">
        <div className="mx-auto w-full max-w-md">
          <div className="mb-8 lg:hidden">
            <Brand />
            <p className="mt-4 text-sm text-muted-foreground">
              Teachers and students use the same door. Your role decides the console.
            </p>
          </div>
          <h2 className="font-display text-4xl tracking-tight">Sign in</h2>
          <p className="mt-2 mb-8 text-sm leading-relaxed text-muted-foreground">
            Use the school email on your classroom account.
          </p>
          <LoginForm />
        </div>
      </section>
    </div>
  )
}
