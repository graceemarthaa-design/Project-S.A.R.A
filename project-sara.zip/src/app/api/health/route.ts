import { prisma } from "@/lib/db"

export const dynamic = "force-dynamic"

export async function GET() {
  try {
    await prisma.$queryRaw`SELECT 1`
    return Response.json({
      ok: true,
      database: "up",
      robot: "not_connected",
    })
  } catch {
    return Response.json(
      { ok: false, database: "down", robot: "not_connected" },
      { status: 503 },
    )
  }
}
