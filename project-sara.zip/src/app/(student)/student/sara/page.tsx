import type { Metadata } from "next"
import { EmptyArea } from "@/components/empty-area"
import { studentAreas } from "@/lib/areas"

const area = studentAreas.sara
export const metadata: Metadata = { title: area.label }

export default function AskSaraPage() {
  return <EmptyArea area={area} />
}
