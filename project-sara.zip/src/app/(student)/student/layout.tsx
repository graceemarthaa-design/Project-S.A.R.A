import { redirect } from "next/navigation"
import { auth } from "@/auth"
import { ConsoleShell } from "@/components/console-shell"
import { navForRole } from "@/lib/areas"
import { roleLabel } from "@/lib/permissions"
import { getLatestStatus } from "@/lib/sara/status"

export const dynamic = "force-dynamic"

export default async function StudentLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const session = await auth()
  if (!session?.user) redirect("/login")
  if (session.user.role !== "student") redirect("/staff")

  const status = await getLatestStatus()

  return (
    <ConsoleShell
      user={{
        name: session.user.name ?? "Student",
        roleLabel: roleLabel(session.user.role),
      }}
      items={navForRole("student")}
      status={status}
    >
      {children}
    </ConsoleShell>
  )
}
