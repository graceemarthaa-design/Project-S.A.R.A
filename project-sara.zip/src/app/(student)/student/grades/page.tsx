import type { Metadata } from "next"
import { EmptyArea } from "@/components/empty-area"
import { studentAreas } from "@/lib/areas"

const area = studentAreas.grades
export const metadata: Metadata = { title: area.label }

export default function GradesPage() {
  return <EmptyArea area={area} />
}
