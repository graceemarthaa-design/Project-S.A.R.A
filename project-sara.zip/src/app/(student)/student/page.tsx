import type { Metadata } from "next"
import { auth } from "@/auth"
import { HomeDashboard } from "@/components/home-dashboard"
import { studentNav } from "@/lib/areas"
import { firstName } from "@/lib/format"
import { getLatestStatus } from "@/lib/sara/status"

export const metadata: Metadata = { title: "Home" }

export default async function StudentHomePage() {
  const session = await auth()
  const name = firstName(session?.user?.name ?? "there")
  const status = await getLatestStatus()

  return (
    <HomeDashboard
      eyebrow="Student"
      title={`${name}, your record lives here.`}
      description="You see your own classes, work, and grades. Other students' records stay out of this console."
      note="This first slice keeps your account and an empty classroom. Announcements, activities, and grade history arrive in later phases. S.A.R.A. will answer from those records once they exist."
      areas={studentNav.filter((area) => area.href !== "/student")}
      status={status}
    />
  )
}
