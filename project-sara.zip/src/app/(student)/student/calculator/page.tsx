import type { Metadata } from "next"
import { EmptyArea } from "@/components/empty-area"
import { studentAreas } from "@/lib/areas"

const area = studentAreas.calculator
export const metadata: Metadata = { title: area.label }

export default function CalculatorPage() {
  return <EmptyArea area={area} />
}
