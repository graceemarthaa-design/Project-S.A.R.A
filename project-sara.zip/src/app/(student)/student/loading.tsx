export default function StudentLoading() {
  return <p className="text-sm text-muted-foreground">Opening your classroom…</p>
}
