"use client"

import { Button } from "@/components/ui/button"

export default function StudentError({
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  return (
    <div className="max-w-lg">
      <h1 className="font-display text-3xl tracking-tight">
        Something interrupted this page.
      </h1>
      <p className="mt-3 text-sm text-muted-foreground">
        Your session is unchanged. Try the page again.
      </p>
      <Button type="button" className="mt-6" onClick={() => reset()}>
        Try again
      </Button>
    </div>
  )
}
