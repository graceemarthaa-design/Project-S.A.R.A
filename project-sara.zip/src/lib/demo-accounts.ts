export const demoAccounts = [
  {
    role: "admin" as const,
    name: "Aki Chandes",
    email: "admin@sara.school",
    password: "Sara-Admin-2026",
    label: "Admin",
  },
  {
    role: "teacher" as const,
    name: "Erica Zambales Montemayor",
    email: "teacher@sara.school",
    password: "Sara-Teacher-2026",
    label: "Teacher",
  },
  {
    role: "student" as const,
    name: "Eunice Zamboanga B. Montemayor",
    email: "student@sara.school",
    password: "Sara-Student-2026",
    label: "Student",
  },
]
