export type AreaIconName =
  | "home"
  | "calendar"
  | "megaphone"
  | "tasks"
  | "grades"
  | "calculator"
  | "help"
  | "message"
  | "classes"
  | "gradebook"
  | "orders"
  | "status"
  | "shield"
  | "people"

export type Area = {
  href: string
  label: string
  icon: AreaIconName
  eyebrow: string
  title: string
  description: string
  emptyTitle: string
  emptyBody: string
  adminOnly?: boolean
}

export const studentAreas = {
  home: {
    href: "/student",
    label: "Home",
    icon: "home",
    eyebrow: "Student",
    title: "Your classroom",
    description: "Schedule, class work, and your own grades.",
    emptyTitle: "",
    emptyBody: "",
  },
  schedule: {
    href: "/student/schedule",
    label: "Schedule",
    icon: "calendar",
    eyebrow: "Week",
    title: "Schedule",
    description: "Meeting days, times, and rooms for your classes.",
    emptyTitle: "Your week is not on the board yet.",
    emptyBody:
      "When a teacher enrolls you in a class, the meeting days, times, and rooms will show up here.",
  },
  announcements: {
    href: "/student/announcements",
    label: "Announcements",
    icon: "megaphone",
    eyebrow: "Notices",
    title: "Announcements",
    description: "Notices from your classes and the school.",
    emptyTitle: "No announcements for your classes.",
    emptyBody:
      "School and class notices will appear here after they are published. You will only see notices for classes you belong to.",
  },
  activities: {
    href: "/student/activities",
    label: "Activities",
    icon: "tasks",
    eyebrow: "Work",
    title: "Activities",
    description: "Requirements, due dates, and what each task is worth.",
    emptyTitle: "No activities or requirements yet.",
    emptyBody:
      "Assignments, quizzes, exams, and participation tasks will list their due dates and what you need to turn in.",
  },
  grades: {
    href: "/student/grades",
    label: "Grades",
    icon: "grades",
    eyebrow: "Record",
    title: "Grades",
    description: "Official scores and the history of every change.",
    emptyTitle: "No official grades yet.",
    emptyBody:
      "When a teacher records a score, it stays in a history. You will see the current score and every change: the previous score, the new score, who changed it, and when.",
  },
  calculator: {
    href: "/student/calculator",
    label: "Grade calculator",
    icon: "calculator",
    eyebrow: "Unofficial",
    title: "Grade calculator",
    description: "Try expected scores without touching the official record.",
    emptyTitle: "The unofficial calculator is not open yet.",
    emptyBody:
      "You will be able to enter expected scores and see a projected course grade. Those guesses stay separate from the official record.",
  },
  help: {
    href: "/student/help",
    label: "Assistance",
    icon: "help",
    eyebrow: "Help",
    title: "Academic assistance",
    description: "Ask a teacher for help on a class.",
    emptyTitle: "No assistance requests yet.",
    emptyBody:
      "You will be able to ask your teacher for academic help on a class. The request and its status stay with that class.",
  },
  sara: {
    href: "/student/sara",
    label: "Ask S.A.R.A.",
    icon: "message",
    eyebrow: "Questions",
    title: "Ask S.A.R.A.",
    description: "Questions answered from your own classroom materials.",
    emptyTitle: "S.A.R.A. is not taking questions yet.",
    emptyBody:
      "Questions will be answered from your schedule, announcements, activities, and your own grades. S.A.R.A. does not see other students' records.",
  },
} as const satisfies Record<string, Area>

export const studentNav: Area[] = [
  studentAreas.home,
  studentAreas.schedule,
  studentAreas.announcements,
  studentAreas.activities,
  studentAreas.grades,
  studentAreas.calculator,
  studentAreas.help,
  studentAreas.sara,
]

export const staffAreas = {
  home: {
    href: "/staff",
    label: "Home",
    icon: "home",
    eyebrow: "Staff",
    title: "Classroom console",
    description: "Classes you teach, and the orders waiting for S.A.R.A.",
    emptyTitle: "",
    emptyBody: "",
  },
  classes: {
    href: "/staff/classes",
    label: "Classes",
    icon: "classes",
    eyebrow: "Roster",
    title: "Classes",
    description: "Sections, rooms, and who is enrolled.",
    emptyTitle: "No classes on this console.",
    emptyBody:
      "Classes, enrollment, and rooms will be managed here. Teachers see the classes assigned to them.",
  },
  announcements: {
    href: "/staff/announcements",
    label: "Announcements",
    icon: "megaphone",
    eyebrow: "Notices",
    title: "Announcements",
    description: "Publish a notice to a class, or school-wide as an admin.",
    emptyTitle: "No announcements yet.",
    emptyBody:
      "Notices you publish will appear for the students enrolled in that class.",
  },
  activities: {
    href: "/staff/activities",
    label: "Activities",
    icon: "tasks",
    eyebrow: "Work",
    title: "Activities",
    description: "Requirements, due dates, weights, and max scores.",
    emptyTitle: "No activities yet.",
    emptyBody:
      "Assignments, quizzes, exams, and participation tasks will be created here, with the requirements students need to meet.",
  },
  gradebook: {
    href: "/staff/gradebook",
    label: "Gradebook",
    icon: "gradebook",
    eyebrow: "Scores",
    title: "Gradebook",
    description: "Record a score. Every later change keeps the previous one.",
    emptyTitle: "The gradebook is empty.",
    emptyBody:
      "Saving a score adds a history row. Changing it requires a reason and keeps the previous score, the new score, who changed it, and when.",
  },
  orders: {
    href: "/staff/orders",
    label: "Orders",
    icon: "orders",
    eyebrow: "Queue",
    title: "Orders for S.A.R.A.",
    description: "Instructions wait here until a robot is connected.",
    emptyTitle: "No orders in the queue.",
    emptyBody:
      "Instructions you give S.A.R.A. will be saved here with a status of queued. Nothing is sent to a robot in this version.",
  },
  status: {
    href: "/staff/status",
    label: "Status and camera",
    icon: "status",
    eyebrow: "Monitor",
    title: "Status and camera",
    description: "What S.A.R.A. last reported, and the classroom camera.",
    emptyTitle: "No status has been recorded.",
    emptyBody: "The robot is not connected, so this panel stays quiet.",
  },
  grants: {
    href: "/staff/grants",
    label: "Personal-data grants",
    icon: "shield",
    eyebrow: "Privacy",
    title: "Personal-data grants",
    description: "Time-bounded permission to see a student's private profile.",
    emptyTitle: "No personal-data grants.",
    emptyBody:
      "A grant names a staff member, a student, a scope, a reason, and an end time. Until a grant is active, student numbers, contact details, and guardian information stay hidden, including from admins.",
    adminOnly: true,
  },
  people: {
    href: "/staff/people",
    label: "People",
    icon: "people",
    eyebrow: "Accounts",
    title: "People",
    description: "Classroom accounts. Private profile fields stay off this list.",
    emptyTitle: "No accounts yet.",
    emptyBody: "Admins will see display names, school emails, and roles here.",
    adminOnly: true,
  },
} as const satisfies Record<string, Area>

export const staffNav: Area[] = [
  staffAreas.home,
  staffAreas.classes,
  staffAreas.announcements,
  staffAreas.activities,
  staffAreas.gradebook,
  staffAreas.orders,
  staffAreas.status,
  staffAreas.grants,
  staffAreas.people,
]

export type NavItem = {
  href: string
  label: string
  icon: AreaIconName
}

export function toNavItem(area: Area): NavItem {
  return { href: area.href, label: area.label, icon: area.icon }
}

export function navForRole(role: "student" | "teacher" | "admin"): NavItem[] {
  const areas = role === "student" ? studentNav : staffNav.filter((item) => !item.adminOnly || role === "admin")
  return areas.map(toNavItem)
}
