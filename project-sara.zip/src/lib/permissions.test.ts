import assert from "node:assert/strict"
import { describe, it } from "node:test"
import {
  canManageGrants,
  canViewPeople,
  homePath,
  isStaff,
  privateProfileFields,
  publicAccountSelect,
} from "./permissions"
import { UnconnectedRobotGateway } from "./sara/gateway"

describe("role homes", () => {
  it("sends students to the student console", () => {
    assert.equal(homePath("student"), "/student")
  })

  it("sends teachers and admins to the staff console", () => {
    assert.equal(homePath("teacher"), "/staff")
    assert.equal(homePath("admin"), "/staff")
  })
})

describe("staff capabilities", () => {
  it("treats teachers and admins as staff", () => {
    assert.equal(isStaff("teacher"), true)
    assert.equal(isStaff("admin"), true)
    assert.equal(isStaff("student"), false)
  })

  it("reserves the directory and personal-data grants for admins", () => {
    assert.equal(canViewPeople("admin"), true)
    assert.equal(canViewPeople("teacher"), false)
    assert.equal(canViewPeople("student"), false)
    assert.equal(canManageGrants("admin"), true)
    assert.equal(canManageGrants("teacher"), false)
  })
})

describe("public account fields", () => {
  it("does not include private profile fields or the password hash", () => {
    const keys = Object.keys(publicAccountSelect)
    for (const field of privateProfileFields) {
      assert.equal(keys.includes(field), false)
    }
    assert.equal(keys.includes("passwordHash"), false)
  })
})

describe("robot gateway", () => {
  it("refuses to deliver a command while the robot is unwired", async () => {
    const gateway = new UnconnectedRobotGateway()
    await assert.rejects(() => gateway.deliver("cmd_1"), /not connected/)
  })
})
