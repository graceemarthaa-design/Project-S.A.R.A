import type { Connectivity } from "@prisma/client"
import { prisma } from "@/lib/db"

export type StatusView = {
  connectivity: Connectivity
  cameraState: string
  mode: string
  battery: number | null
  note: string
  recordedAt: string
}

export async function getLatestStatus(): Promise<StatusView | null> {
  const snapshot = await prisma.saraStatusSnapshot.findFirst({
    orderBy: { recordedAt: "desc" },
  })
  if (!snapshot) return null
  return {
    connectivity: snapshot.connectivity,
    cameraState: snapshot.cameraState,
    mode: snapshot.mode,
    battery: snapshot.battery,
    note: snapshot.note,
    recordedAt: snapshot.recordedAt.toISOString(),
  }
}

export function connectivityLabel(connectivity: Connectivity) {
  if (connectivity === "simulated") return "Simulated"
  if (connectivity === "online") return "Online"
  return "Offline"
}

export function cameraLabel(cameraState: string) {
  if (cameraState === "not_connected") return "Camera not connected"
  return `Camera ${cameraState}`
}
