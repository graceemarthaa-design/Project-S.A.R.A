/**
 * Seam for the physical robot. This build ships the interface only.
 * No URL, socket, or camera stream is opened.
 */
export type RobotDelivery = {
  commandId: string
  status: "queued" | "sent" | "acknowledged" | "completed" | "failed" | "cancelled"
}

export interface RobotGateway {
  deliver(commandId: string): Promise<RobotDelivery>
}

export class UnconnectedRobotGateway implements RobotGateway {
  async deliver(commandId: string): Promise<RobotDelivery> {
    throw new Error(
      `S.A.R.A. is not connected. Command ${commandId} stays queued.`,
    )
  }
}
