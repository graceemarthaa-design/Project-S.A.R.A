import type { Role } from "@prisma/client"

export function homePath(role: Role) {
  return role === "student" ? "/student" : "/staff"
}

export function isStaff(role: Role) {
  return role === "teacher" || role === "admin"
}

export function canManageGrants(role: Role) {
  return role === "admin"
}

export function canViewPeople(role: Role) {
  return role === "admin"
}

/** Columns safe to show on the admin directory. Personal profile fields are absent. */
export const publicAccountSelect = {
  id: true,
  displayName: true,
  email: true,
  role: true,
  status: true,
} as const

export const privateProfileFields = [
  "studentNumber",
  "personalEmail",
  "phone",
  "address",
  "guardianName",
  "guardianPhone",
  "notes",
] as const

export function roleLabel(role: Role) {
  if (role === "admin") return "Admin"
  if (role === "teacher") return "Teacher"
  return "Student"
}
