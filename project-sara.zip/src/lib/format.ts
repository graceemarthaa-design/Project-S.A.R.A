export function formatWhen(iso: string) {
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "UTC",
  }).format(new Date(iso))
}

export function firstName(displayName: string) {
  return displayName.trim().split(/\s+/)[0] || displayName
}
