# Project S.A.R.A.

Classroom web app for teachers, admins, and students. This repository is **phase 1**: accounts, role-based consoles, and empty states for the classroom areas that come next.

The physical robot is not connected. Staff can see a simulated offline status and a dark camera panel. Orders are not sent anywhere.

## What you can do now

- Sign in as an admin, a teacher, or a student.
- Land in the matching console. Students cannot open staff screens, and staff cannot open the student console.
- Admins can see the account directory (name, school email, role, status). Personal profile fields are stored separately and are not shown.
- Teachers who open personal-data grants see a closed screen.
- The status panel reads the latest simulated snapshot from the database.

Grades, announcements, activities, assistance, questions, and robot delivery are later phases. Those screens explain what will appear there.

## Stack

Next.js, TypeScript, Tailwind CSS, shadcn/ui, PostgreSQL, Prisma, and Auth.js (credentials).

## Local setup

1. Start PostgreSQL. With Docker:

```bash
docker compose up -d
```

Or use any local Postgres 16 and match the URL below.

2. Copy the environment file and set a real `AUTH_SECRET`:

```bash
cp .env.example .env
openssl rand -base64 32
```

3. Install, migrate, and seed the three demo accounts:

```bash
npm install
npx prisma migrate deploy
npx prisma db seed
npm run dev
```

The app listens on [http://127.0.0.1:4317](http://127.0.0.1:4317).

## Demo accounts

| Role | Name | Email | Password |
| --- | --- | --- | --- |
| Admin | Aki Chandes | admin@sara.school | Sara-Admin-2026 |
| Teacher | Erica Zambales Montemayor | teacher@sara.school | Sara-Teacher-2026 |
| Student | Eunice Zamboanga B. Montemayor | student@sara.school | Sara-Student-2026 |

The sign-in screen can fill these in. They exist only for local development.

Eunice's private profile (student number, phone, address, guardian) is seeded and is not rendered on any screen in this phase.

## Checks

```bash
npm test
npm run lint
```

`GET /api/health` reports whether the database is up. The robot field stays `not_connected`.

## Later phases

2. Classes, enrollment, and schedules.
3. Announcements and activities.
4. Official grades with an append-only change history.
5. Unofficial grade calculator.
6. Assistance requests and questions answered from classroom data.
7. In-class sessions and a command queue that stays queued.
8. Time-bounded personal-data grants and an audit view.
9. A robot gateway contract, still without a network client.
