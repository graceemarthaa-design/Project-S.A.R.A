import { PrismaClient } from "@prisma/client"
import { hash } from "bcryptjs"
import { demoAccounts } from "../src/lib/demo-accounts"

const prisma = new PrismaClient()

async function main() {
  for (const account of demoAccounts) {
    const passwordHash = await hash(account.password, 10)
    const user = await prisma.user.upsert({
      where: { email: account.email },
      update: {
        displayName: account.name,
        role: account.role,
        passwordHash,
        status: "active",
      },
      create: {
        email: account.email,
        displayName: account.name,
        role: account.role,
        passwordHash,
        status: "active",
      },
    })

    if (account.role === "student") {
      await prisma.studentProfile.upsert({
        where: { userId: user.id },
        update: {},
        create: {
          userId: user.id,
          studentNumber: "S-10428",
          personalEmail: "elena.home@example.com",
          phone: "555-0148",
          address: "18 Cedar Lane",
          guardianName: "Rosa Vasquez",
          guardianPhone: "555-0192",
          notes: "Contact the guardian before any schedule change.",
        },
      })
    }
  }

  const existingStatus = await prisma.saraStatusSnapshot.findFirst()
  if (!existingStatus) {
    await prisma.saraStatusSnapshot.create({
      data: {
        mode: "standby",
        connectivity: "simulated",
        battery: null,
        cameraState: "not_connected",
        note: "No robot is linked. Status on this screen is simulated.",
      },
    })
  }
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (error) => {
    console.error(error)
    await prisma.$disconnect()
    process.exit(1)
  })
